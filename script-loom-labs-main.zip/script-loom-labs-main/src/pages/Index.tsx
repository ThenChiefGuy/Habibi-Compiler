import CodeCompiler from "@/components/CodeCompiler";

const Index = () => {
  return <CodeCompiler />;
};

export default Index;
